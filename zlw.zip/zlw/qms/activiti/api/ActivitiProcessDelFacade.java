//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.zlw.qms.activiti.api;

import com.zlw.qms.activiti.api.factory.ActivitiQueryTaskFallbackFactory;
import com.zlw.qms.common.core.domain.R;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(value = "qms-workflow-service", url = "10.30.10.100:31204", path = "", fallbackFactory = ActivitiQueryTaskFallbackFactory.class)
@Validated
public interface ActivitiProcessDelFacade {
    @DeleteMapping({"/processInst/removeBusinessKeyInstance/{businessKeys}"})
    R<Boolean> removeBusinessKeyInstance(@PathVariable("businessKeys") String[] var1);
}
