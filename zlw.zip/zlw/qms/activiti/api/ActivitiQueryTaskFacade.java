package com.zlw.qms.activiti.api;

import com.zlw.qms.activiti.api.factory.ActivitiQueryTaskFallbackFactory;
import com.zlw.qms.common.core.domain.R;
import com.zlw.qms.common.core.web.domain.AjaxResult;
import com.zlw.qms.common.core.web.domain.activiti.dto.ActProcessInstResDTO;
import com.zlw.qms.common.core.web.domain.activiti.dto.ActTaskResDTO;
import io.swagger.annotations.ApiOperation;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

/**
 * Activiti工作流通用查询接口
 *
 * @author 翁亮
 */
@FeignClient(value = "qms-workflow-service", url = "10.30.10.100:31204", path = "", fallbackFactory = ActivitiQueryTaskFallbackFactory.class)
@Validated
public interface ActivitiQueryTaskFacade {

    /**
     * 通过实例ID获取实例流转信息
     *
     * @param proInstId 流程实例ID
     * @return Object
     */
    @GetMapping(value = "/historyFromData/getFlowRecording")
    public AjaxResult historyDataShowTaskList(@RequestParam(value = "proInstId") String proInstId);

    /**
     * 通过businessKey 返回流程实例ID数组
     *
     * @param businessKey 表单ID
     * @return List<String>
     */
    @ApiOperation("通过businessKey 返回流程实例ID数组")
    @GetMapping(value = "/processInst/getProcessInstIds/{businessKey}")
    public List<String> getProcessInstIds(@PathVariable("businessKey") String businessKey);

    /**
     * 通过流程实例ID查询最新流程任务
     *
     * @param proInstId 流程实例ID
     * @return List<ActTaskDTO>
     */
    @GetMapping(value = "/task/process/getTaskDtoList/{proInstId}")
    public R<List<ActTaskResDTO>> getTaskDtoList(@PathVariable("proInstId") String proInstId);

    /**
     * 查询当前任务是否已经完成
     *
     * @param taskId 任务ID
     * @return List<ActTaskDTO>
     */
    @GetMapping(value = "/task/checkTaskCompletedS/{taskId}")
    public R<Boolean> checkTaskCompletedS(@PathVariable("taskId") String taskId);

    /**
     * 通过流程实例ID获取流程实例
     *
     * @param proInstId 实例ID
     * @return List<String>
     */
    @GetMapping(value = "/processInst/getProcessInstExample/{proInstId}")
    public R<ActProcessInstResDTO> getProcessInstExample(@PathVariable("proInstId") String proInstId);

    /**
     * 通过表单ID获取历史流程动态表单信息
     *
     * @param businessKeys 表单ID
     * @return Object
     */
    @GetMapping(value = "/historyFromData/getProInstIdFormDataMap")
    public AjaxResult getProInstIdFormDataMap(@RequestParam("businessKeys") String[] businessKeys);

}
