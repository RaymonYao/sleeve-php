package com.zlw.qms.activiti.api;

import com.zlw.qms.activiti.api.factory.ActivitiTaskCmdFallbackFactory;
import com.zlw.qms.common.core.domain.R;
import com.zlw.qms.common.core.web.domain.activiti.dto.ActTaskResDTO;
import com.zlw.qms.common.core.web.domain.activiti.vo.ActWorkflowFormDataVO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

/**
 * Activiti工作流通用命令接口
 *
 * @author 翁亮
 */
@FeignClient(value = "qms-workflow-service", url = "10.30.10.100:31204", path = "", fallbackFactory = ActivitiTaskCmdFallbackFactory.class)
@Validated
public interface ActivitiTaskCmdFacade
{

    /**
     * 跳转至指定活动节点
     * @param taskId 任务id
     * @param targetTaskKey 跳转至目标任务key
     * @return
     */
    @GetMapping(value = "/task/process/jumpWorkItem/{taskId}/{targetTaskKey}")
    public R<Boolean> jumpWorkItem(@PathVariable("taskId") String taskId, @PathVariable("targetTaskKey") String targetTaskKey);

    /**
     * 任务挂起
     * @param proInstId 流程实例ID
     * @return
     */
    @GetMapping(value = "/task/process/suspendProcessInstanceById/{proInstId}")
    public R<Boolean> suspendProcessInstanceById(@PathVariable("proInstId") String proInstId);

    /**
     * 任务激活
     * @param proInstId 流程实例ID
     * @return
     */
    @GetMapping(value = "/task/process/activateProcessInstanceById/{proInstId}")
    public R<Boolean> activateProcessInstanceById(@PathVariable("proInstId") String proInstId);

    /**
     * 任务流程终止
     * @param businessKey 流程表单ID
     * @return
     */
    @GetMapping(value = "/processInst/stopRunProcessInstance/{businessKey}")
    public R<String> stopRunProcessInstance(@PathVariable("businessKey") String businessKey);

    /**
     * 跳转至指定活动节点流转信息
     *
     * @param vo            任务信息
     * @param targetTaskKey 跳转至目标任务key
     * @return
     */
    @PostMapping(value = "/task/process/jumpWorkItem/{targetTaskKey}")
    public R<List<ActTaskResDTO>> jumpWorkItem(@PathVariable("targetTaskKey") String targetTaskKey, @RequestBody ActWorkflowFormDataVO vo);


}
