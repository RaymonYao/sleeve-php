package com.zlw.qms.activiti.api;

import com.zlw.qms.activiti.api.domain.vo.ActTaskCirculateVo;
import com.zlw.qms.activiti.api.factory.ActivitiTaskFallbackFactory;
import com.zlw.qms.common.core.constant.CacheConstants;
import com.zlw.qms.common.core.constant.SecurityConstants;
import com.zlw.qms.common.core.constant.ServiceNameConstants;
import com.zlw.qms.common.core.domain.R;
import com.zlw.qms.common.core.web.domain.activiti.dto.ActTaskResDTO;
import com.zlw.qms.common.core.web.domain.activiti.dto.StartWorkflowDTO;
import com.zlw.qms.common.core.web.domain.activiti.vo.ActWorkflowFormDataVO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Activiti工作流通用接口
 *
 * @author 翁亮
 */
@FeignClient(value = "qms-workflow-service", url = "10.30.10.100:31204", path = "", fallbackFactory = ActivitiTaskFallbackFactory.class)
@Validated
public interface ActivitiTaskFacade
{

    /**
     * 启动流程
     * @param startWorkflow
     * @return
     */
    @PostMapping(value = "/task/createAndStartProcessInstance")
    public R<List<ActTaskResDTO>> createAndStartProcessInstance(@RequestBody StartWorkflowDTO startWorkflow);

    /**
     * 启动流程（携带token）
     * @param startWorkflow
     * @return
     */
    @PostMapping(value = "/task/createAndStartProcessInstance")
    public R<List<ActTaskResDTO>> createAndStartProcessInstance(@RequestBody StartWorkflowDTO startWorkflow, @RequestHeader(CacheConstants.AUTHORIZATION_HEADER) String token);

    /**
     * 触发流程
     * @param flow
     * @return
     */
    @PostMapping(value = "/task/triggerAndStartProcessInstance")
    public R<List<ActTaskResDTO>> triggerAndStartProcessInstance(@RequestBody StartWorkflowDTO flow);

    /**
     * 启动流程子扩展流程
     * @param startWorkflow
     * @return
     */
    @PostMapping(value = "/task/startWorkflowSubExtension")
    public boolean startWorkflowSubExtension(@RequestBody StartWorkflowDTO startWorkflow);

    /**
     * 通用审批流程
     * @param actWorkflowFormDataVO
     * @return 成功/失败
     */
    @PostMapping(value = "/task/process/approval")
    public R<List<ActTaskResDTO>> processApproval(@RequestBody ActWorkflowFormDataVO actWorkflowFormDataVO);

    /**
     * 通用审批流程（携带token）
     * @param actWorkflowFormDataVO
     * @return 成功/失败
     */
    @PostMapping(value = "/task/process/approval")
    public R<List<ActTaskResDTO>> processApproval(@RequestBody ActWorkflowFormDataVO actWorkflowFormDataVO, @RequestHeader(CacheConstants.AUTHORIZATION_HEADER) String token);

    /**
     * 保存流程数据
     * @param actWorkflowFormDataVO
     * @return 成功/失败
     */
    @PostMapping(value = "/task/process/saveProcessInfo")
    public R<List<ActTaskResDTO>> saveProcessInfo(@RequestBody ActWorkflowFormDataVO actWorkflowFormDataVO);

    /**
     * 保存流程数据
     * @param actWorkflowFormDataVO（携带token）
     * @return 成功/失败
     */
    @PostMapping(value = "/task/process/saveProcessInfo")
    public R<List<ActTaskResDTO>> saveProcessInfo(@RequestBody ActWorkflowFormDataVO actWorkflowFormDataVO, @RequestHeader(CacheConstants.AUTHORIZATION_HEADER) String token);


    /**
     * 通过任务id + 变量key 查询对应的流程变量信息
     * @param taskId 任务id
     * @param key 流程变量唯一key
     * @return Object
     */
    @GetMapping(value = "/processInst/getVariable/{taskId}/{key}")
    public Object getVariable(@PathVariable("taskId") String taskId, @PathVariable("key") String key);


    /**
     * 任务传阅
     * @param deploymentId 当前流程定义ID
     * @param businessKey 当前businessKey（对应表单的主键ID）
     * @param title 流程标题
     * @param userIds 传阅人数组
     * @return 成功/失败
     */
    @PostMapping(value = "/task/process/circulateWorkItem")
    public R<List<ActTaskResDTO>> circulateWorkItem(@RequestParam("deploymentId") String deploymentId, @RequestParam("businessKey") String businessKey, @RequestParam("title") String title, @RequestParam("userIds") String[] userIds);

    /**
     *  传阅任务V2
     * @param var1
     * @return
     */

    @PostMapping({"/task/process/circulateWorkItemV2"})
    R<List<ActTaskResDTO>> circulateWorkItemV2(@RequestBody ActTaskCirculateVo var1);
    /**
     * 通过任务流程实例ID更新流程标题
     * @param proInstId 流程实例ID
     * @param title 标题值
     * @return boolean
     */
    @PutMapping(value = "/processInst/setProcessInstanceName")
    public R<Boolean> setProcessInstanceName(@RequestParam(value = "proInstId") String proInstId,@RequestParam(value = "title") String title);


    /**
     * 任务传阅
     * @param detailRouter 表单地址
     * @param businessKey 当前businessKey（对应表单的主键ID）
     * @param title 流程标题
     * @param userIds 传阅人数组
     * @return 成功/失败
     */
    @PostMapping(value = "/task/process/circulateTaskFrom")
    public R<Boolean> circulateTaskFrom(@RequestParam("detailRouter") String detailRouter,@RequestParam("businessKey") String businessKey,@RequestParam("title") String title,@RequestParam("userIds") String[] userIds,@RequestHeader(SecurityConstants.SOURCE_KEY) String sourceKey);

    /**
     * 通过任务id && 流程变量Map更新当前流程变量信息
     *
     * @return Object
     */
    @PostMapping(value = "/task/setVariable")
    public boolean setVariable(@RequestBody ActWorkflowFormDataVO actWorkflowFormDataVO);



}
