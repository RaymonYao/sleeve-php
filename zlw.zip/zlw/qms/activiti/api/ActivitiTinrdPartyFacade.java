package com.zlw.qms.activiti.api;

import com.zlw.qms.activiti.api.factory.ActivitiTaskFallbackFactory;
import com.zlw.qms.common.core.constant.ServiceNameConstants;
import com.zlw.qms.common.core.web.domain.activiti.dto.ActTaskResDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * Activiti工作流通用接口
 *
 * @author 翁亮
 */
@FeignClient(contextId = "activitiTinrdPartyFacade", value = ServiceNameConstants.WORKFLOW_SERVICE, url = "10.30.10.100:31204", fallbackFactory = ActivitiTaskFallbackFactory.class)
@Validated
public interface ActivitiTinrdPartyFacade
{

    /**
     * 发送钉钉卡片工作通知
     * @param event
     * @return
     */
    @PostMapping(value = "/activitiCommon/sendDingtalk")
    public void sendDingtalk(@RequestBody ActTaskResDTO event);
}
