package com.zlw.qms.message.api.provider;

import com.zlw.qms.common.core.constant.SecurityConstants;
import com.zlw.qms.common.core.web.domain.AjaxResult;
import com.zlw.qms.message.api.domain.EmailBuilder;
import com.zlw.qms.message.api.provider.factory.RemoteBaseMessageFallbackFactory;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;


/**
 * 消息服务接口
 *
 * @author 翁亮
 */
@FeignClient(value = "qms-system-service", url = "10.30.10.100:31201", fallbackFactory = RemoteBaseMessageFallbackFactory.class)
public interface RemoteBaseMessageService
{

    /**
     * 发送邮箱服务信息（携带token）
     *
     * @return 结果
     */
    @PostMapping(value = "/message/email/sendEmail")
    public AjaxResult sendEmail(@RequestBody EmailBuilder email, @RequestHeader(SecurityConstants.SOURCE_KEY) String sourceKey);


    /**
     * 按照服务标识发送邮箱服务信息（携带token）
     *
     * @param mark 邮箱服务唯一标识
     * @return 结果
     */
    @PostMapping(value = "/message/email/sendEmail/{mark}")
    public AjaxResult sendEmail(@PathVariable(value = "mark") String mark, @RequestBody EmailBuilder email, @RequestHeader(SecurityConstants.SOURCE_KEY) String sourceKey);

}
