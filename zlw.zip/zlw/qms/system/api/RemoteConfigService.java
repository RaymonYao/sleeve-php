package com.zlw.qms.system.api;

import com.zlw.qms.common.core.web.domain.AjaxResult;
import com.zlw.qms.system.api.factory.RemoteConfigFallbackFactory;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * 系统参数
 *
 * @author 翁亮
 */
@FeignClient(value = "qms-system-service", url = "10.30.10.100:31201", fallbackFactory = RemoteConfigFallbackFactory.class)
public interface RemoteConfigService {

    /**
     * 根据参数键名查询参数值
     *
     * @param configKey 参数键名
     * @return 结果
     */
    @GetMapping(value = "/config/configKey/{configKey}")
    public AjaxResult getConfigKey(@PathVariable(value = "configKey") String configKey);

}
