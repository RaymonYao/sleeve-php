package com.zlw.qms.system.api;

import com.zlw.qms.common.core.constant.SecurityConstants;
import com.zlw.qms.common.core.constant.ServiceNameConstants;
import com.zlw.qms.common.core.domain.R;
import com.zlw.qms.common.core.web.domain.AjaxResult;
import com.zlw.qms.system.api.domain.SysDept;
import com.zlw.qms.system.api.factory.RemoteConfigFallbackFactory;
import com.zlw.qms.system.api.factory.RemoteDeptFallbackFactory;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import java.util.List;

/**
 * 部门服务
 *
 * @author 翁亮
 */
@FeignClient(value = "qms-system-service", url = "10.30.10.100:31201", fallbackFactory = RemoteDeptFallbackFactory.class)
public interface RemoteDeptService
{
    /**
     * 根据部门Id获取详细信息
     *
     * @param deptCode 部门编码
     * @return 结果
     */
    @GetMapping(value = "/dept/getDeptByCode/{deptCode}")
    public AjaxResult getDeptCode(@PathVariable(value = "deptCode") String deptCode, @RequestHeader(SecurityConstants.SOURCE_KEY) String sourceKey);


    /**
     * 树形部门信息同步
     * @param datas 部门信息
     * @return 结果
     */
    @PostMapping(value = "/external/synchronize/synDpetInfo")
    public R<Boolean> synDpetInfo(@Validated @RequestBody List<SysDept> datas, @RequestHeader(SecurityConstants.SOURCE_KEY) String sourceKey);

    /**
     * 部门批量同步
     * @param datas 部门信息
     * @return 结果
     */
    @PostMapping(value = "/external/synchronize/synBatchDpetInfo")
    public R<Boolean> synBatchDpetInfo(@Validated @RequestBody List<SysDept> datas, @RequestHeader(SecurityConstants.SOURCE_KEY) String sourceKey);



    @GetMapping(value = "/dept/getDeptAll")
    public AjaxResult getDeptAll(@RequestHeader(SecurityConstants.SOURCE_KEY) String sourceKey);

}
