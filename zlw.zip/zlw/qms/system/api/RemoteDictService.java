package com.zlw.qms.system.api;

import com.zlw.qms.common.core.constant.CacheConstants;
import com.zlw.qms.common.core.constant.ServiceNameConstants;
import com.zlw.qms.common.core.web.domain.AjaxResult;
import com.zlw.qms.system.api.domain.SysDictData;
import com.zlw.qms.system.api.factory.RemoteConfigFallbackFactory;
import com.zlw.qms.system.api.factory.RemoteDictFallbackFactory;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

/**
 * 数据字段
 *
 * @author 翁亮
 */
@FeignClient(value = "qms-system-service", url = "10.30.10.100:31201",path = "", fallbackFactory = RemoteDictFallbackFactory.class)
public interface RemoteDictService
{

    /**
     * 根据字典类型查询字典数据信息
     *
     * @param dictType 字段类型
     * @return 结果
     */
    @GetMapping(value = "/dict/data/type/{dictType}")
    public AjaxResult dictType(@PathVariable(value = "dictType") String dictType);

    /**
     * 根据字典类型查询字典数据信息(携带token)
     *
     * @param dictType 字段类型
     * @return 结果
     */
    @GetMapping(value = "/dict/data/type/{dictType}")
    public AjaxResult dictType(@PathVariable(value = "dictType") String dictType, @RequestHeader(CacheConstants.AUTHORIZATION_HEADER) String token);

    /**
     * 修改保存字典类型 (携带token)
     *
     * @param dict 字段类型
     * @return 结果
     */
    @PutMapping(value = "/dict/data")
    public AjaxResult edit(@Validated @RequestBody SysDictData dict);

    /**
     * 修改保存字典类型
     *
     * @param dict 字段类型
     * @return 结果
     */
    @PutMapping(value = "/dict/data")
    public AjaxResult edit(@Validated @RequestBody SysDictData dict, @RequestHeader(CacheConstants.AUTHORIZATION_HEADER) String token);
}
