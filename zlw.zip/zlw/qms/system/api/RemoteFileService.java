//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.zlw.qms.system.api;

import com.zlw.qms.common.core.domain.R;
import com.zlw.qms.system.api.domain.SysFile;
import com.zlw.qms.system.api.domain.dto.SysFileDataDto;
import com.zlw.qms.system.api.domain.dto.SysUploadFileDto;
import com.zlw.qms.system.api.factory.RemoteFileFallbackFactory;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@FeignClient(value = "qms-file-service", url = "10.30.10.100:30123", path = "", fallbackFactory = RemoteFileFallbackFactory.class)
public interface RemoteFileService {
    @PostMapping(
        value = {"/upload"},
        consumes = {"multipart/form-data"}
    )
    R<SysFile> upload(@RequestPart("file") MultipartFile var1);

    @PostMapping(
        value = {"/uploadByBase64"},
        consumes = {"application/json"}
    )
    R<SysFile> uploadByBase64(@RequestBody SysUploadFileDto var1);

    @GetMapping({"/getInfoFile"})
    R<SysFileDataDto> getInfoFile(@RequestParam("id") String var1, @RequestHeader("authorization") String var2);

    @DeleteMapping({"/removeFile"})
    R<Boolean> removeFile(@RequestParam("id") String var1, @RequestHeader("authorization") String var2);
}
