package com.zlw.qms.system.api;

import com.zlw.qms.common.core.constant.SecurityConstants;
import com.zlw.qms.common.core.domain.R;
import com.zlw.qms.system.api.domain.SysUser;
import com.zlw.qms.system.api.factory.RemotePostFallbackFactory;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;

import java.util.List;

/**
 * 岗位服务
 *
 * @author 翁亮
 */
@FeignClient(value = "qms-system-service", url = "10.30.10.100:31201", path = "", fallbackFactory = RemotePostFallbackFactory.class)
public interface RemotePostService {
    /**
     * 根据岗位编号获取人员信息
     *
     * @param postCode 岗位编码
     * @return 结果
     */
    @GetMapping(value = "/post/getPostCodeOrUserInfo/{postCode}")
    public R<List<SysUser>> getPostCodeOrUserInfo(@PathVariable(value = "postCode") String postCode, @RequestHeader(SecurityConstants.SOURCE_KEY) String sourceKey);
}
