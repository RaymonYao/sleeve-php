package com.zlw.qms.system.api;

import com.zlw.qms.common.core.domain.R;
import com.zlw.qms.system.api.domain.vo.SysRoleUserVo;
import com.zlw.qms.system.api.factory.RemoteRoleFallbackFactory;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;


/**
 * 角色服务
 *
 * @author 翁亮
 */
@FeignClient(value = "qms-system-service", url = "10.30.10.100:31201", path = "", fallbackFactory = RemoteRoleFallbackFactory.class)
public interface RemoteRoleService {

    /**
     * 根据角色权限获取角色下所有的人员信息
     *
     * @param roleKey 角色权限
     * @return 结果
     */
    @GetMapping(value = "/role/roleUsers/{roleKey}")
    public R<List<SysRoleUserVo>> getRoleUsers(@PathVariable(value = "roleKey") String roleKey);

}
