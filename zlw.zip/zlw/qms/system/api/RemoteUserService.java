package com.zlw.qms.system.api;

import com.zlw.qms.common.core.constant.SecurityConstants;
import com.zlw.qms.common.core.domain.R;
import com.zlw.qms.system.api.domain.SysUser;
import com.zlw.qms.system.api.factory.RemoteUserFallbackFactory;
import com.zlw.qms.system.api.model.LoginUser;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 用户服务
 *
 * @author 翁亮
 */
@FeignClient(value = "qms-system-service", url = "10.30.10.100:31201", path = "", fallbackFactory = RemoteUserFallbackFactory.class)
public interface RemoteUserService {
    /**
     * 通过用户名查询用户信息
     *
     * @param username 用户名
     * @return 结果
     */
    @GetMapping(value = "/user/info/{username}")
    public R<LoginUser> getUserInfo(@PathVariable(value = "username") String username, @RequestHeader(SecurityConstants.SOURCE_KEY) String sourceKey);

    /**
     * 获取当前部门所属人员
     *
     * @param deptCode 部门code
     * @return 结果
     */
    @GetMapping(value = "/user/queryDeptCode/userListAll")
    public R<List<SysUser>> getDeptCodeUserListAll(@RequestParam(value = "deptCode") String deptCode, @RequestHeader(SecurityConstants.SOURCE_KEY) String sourceKey);

    /**
     * 人员信息同步
     *
     * @param datas 用户信息
     * @return 结果
     */
    @PostMapping(value = "/external/synchronize/synUserInfo")
    public R<Boolean> synUserInfo(@Validated @RequestBody List<SysUser> datas, @RequestHeader(SecurityConstants.SOURCE_KEY) String sourceKey);

    /**
     * 通过用户名查询真实姓名
     *
     * @param username 用户名
     * @return 结果
     */
    @GetMapping(value = "/user/info/nickname/{username}")
    public String getNickName(@PathVariable(value = "username") String username, @RequestHeader(SecurityConstants.SOURCE_KEY) String sourceKey);

}
